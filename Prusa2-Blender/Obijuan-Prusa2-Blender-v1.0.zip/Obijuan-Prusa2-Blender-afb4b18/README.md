Prusa2-Blender
==============

A virtual Prusa iteration 2 designed in Blender