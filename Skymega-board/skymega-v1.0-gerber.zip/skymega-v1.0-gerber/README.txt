Skymega board 1.0 (2011)
--------------------

The board has 2 layers: Front and Back

Files for manufacturing: 

GERBER:

  * skymega-Front.gtl        Front cooper layer
  * skymega-Mask_Front.gts   Front Solder Mask
  * skymega-SilkS_Front.gto  Front Silkscreen

  * skymega-Back.gbl         Back cooper layer
  * skymega-Mask_Back.gbs    Back Solder Mask
  * skymega-SilkS_Back.gbo   Back Silkscreen

DRILLs:

  * Skymega.drl








